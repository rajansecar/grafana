/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.podaa;

/**
 *
 * @author welcome
 */
public class EducationDetail {
    
    private String classOrDegree;
    private String boardOrUniversity;
    private Integer passedYear;
    private Integer percentage;

    public EducationDetail(String classOrDegree, String boardOrUniversity, Integer passedYear, Integer percentage) {
        this.classOrDegree = classOrDegree;
        this.boardOrUniversity = boardOrUniversity;
        this.passedYear = passedYear;
        this.percentage = percentage;
    }
    
    public String getClassOrDegree() {
        return classOrDegree;
    }

    public void setClassOrDegree(String classOrDegree) {
        this.classOrDegree = classOrDegree;
    }

    public String getBoardOrUniversity() {
        return boardOrUniversity;
    }

    public void setBoardOrUniversity(String boardOrUniversity) {
        this.boardOrUniversity = boardOrUniversity;
    }

    public Integer getPassedYear() {
        return passedYear;
    }

    public void setPassedYear(Integer passedYear) {
        this.passedYear = passedYear;
    }

    public Integer getPercentage() {
        return percentage;
    }

    public void setPercentage(Integer percentage) {
        this.percentage = percentage;
    }
    
    
    
}
